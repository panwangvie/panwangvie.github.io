

## 1. 安装Hugo



1. **使用Chocolatey搭建**

   * 安装 https://chocolatey.org/install（包管理器）。

   PowerShell执行管理员身份下面命令先安装**Chocolatey**

   ```plain&#x20;text
   Set-ExecutionPolicy Bypass -Scope Process -Force; [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072; iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))
   ```

   * 命令行执行：

   ```bash
   choco install hugo -confirm #安装hugo
   ```

![](images/image-6.png)

安装hugo拓展版

```python
choco install hugo-extended -y --confirm #安装Hugo 扩展版（必需）​
```

![](images/image-5.png)

## 2. **创建 Hugo 项目**

1. **初始化项目**

执行如下命令创建Hugo项目

```bash
# 1. 创建 Hugo 项目
hugo new site my-blog
cd my-blog
# 2. 初始化 Git 仓库
git init

```

* **添加主题子模块**

```bash
# 3. 添加主题子模块（必须在项目根目录执行）
git submodule add https://github.com/adityatelange/hugo-PaperMod themes/PaperMod
# 4. 验证
ls themes/PaperMod  # 应看到主题文件
cat .gitmodules     # 应显示子模块配置
```

&#x20;     在添加主题的时候由于网速比较慢，所有经常下载主题失败。我使用如下方式添加主题，先 clone主题下来，在执行submodule。

```bash
#添加主题子模块（必须在项目根目录执行）
git clone https://github.com/adityatelange/hugo-PaperMod themes/PaperMod
git submodule add https://github.com/adityatelange/hugo-PaperMod themes/PaperMod
```

![](images/image-4.png)

&#x20;**更多添加主题：**&#x4ECE;<https://themes.gohugo.io/>下载喜欢的主题，直接拷贝至 technical\_blog/themes 目录，并修改配置文件 hugo.toml，删除 url 字段，添加 theme=' 主题名 '。

2. **配置主题**

修改 `hugo.toml` 文件，Hugo支持TOML、YAML和JSON三种格式配置文件，优先级为hugo.toml > hugo.yaml > hugo.json

```python
baseURL = 'https://panwangvie.github.io'
languageCode = 'zh-cn'
title = 'My New Hugo Site'
theme = "PaperMod" #使用的主题
defaultContentLanguage = "zh-cn"  # 新增此行，设置默认语言为中文

[build]
  publishDir = "public"

# 中文语言配置
[languages.zh-cn]
  weight = 1
  title = "我的博客"
  languageName = "中文"

[params]
  dateFormat = "2006-01-02"
  [params.social]
    GitHub = "https://github.com/panwangvie"
```

&#x20;



## 3. **启动本地服务器验证**

确保配置正确后，启动 Hugo 本地预览：

```bash
hugo new posts/hello-world.md #创建一个md
hugo server -D #运行服务
hugo -D --minify 
```

* 如果成功，浏览器访问 `http://localhost:1313` 会显示基于 PaperMod 主题的博客。

![](images/image-3.png)



## 4. 部署到GitHub

1. 发布网站：执行 hugo 命令在项目根目录的 public 目录中创建整个静态站点。

2. 部署到 GitHub：在 GitHub 上创建名为 {用户名}.github.io 的仓库，将本地项目的 public 文件夹中的内容推送到该仓库，即可通过 https://{用户名}.github.io 访问博客。

```bash
git add .
git commit -m "初始化个人博客"
git remote add origin https://github.com/<用户名>/<用户名>.github.io.git
git push -u origin main
```

![](images/image-2.png)

我搭建的Demo https://panwangvie.github.io/

![](images/image-1.png)

## 5. 博客评论系统的使用

博客中的评论系统是很重要的。这里我使用的是 Stack 模板支持的 **Waline**，搭建很简单，可以参考 [Waline 官方指南](https://waline.js.org/guide/get-started/)。

配置 Waline 则可以参考这篇博客 [hugo：添加评论功能（Waline） - 建站指南](https://site.zhelper.net/Hugo/hugo-comment/)，我的 Waline 配置：

```bash
         # Waline 评论系统配置，参考：https://waline.js.org/en/reference/component.html        waline:
        waline:
            # 这里填你的vercel服务器地址。
            # vercel自定义域名会和cloudflare会冲突导致无限301,所以干脆直接用送的域名了
            # 注意要部署总域名，而不是最新部署的版本域名（中间有一段随机英文字符的），否则会报 401 Unauthorized
            serverURL: https://waline-你的用户名.vercel.app/
            lang: zh-CN
            # 文章浏览量统计，在新版waline中已更名为pageview属性，貌似用不了了
            # 填入false代表不启用，填入字符串的时候会作为css选择器
            visitor: false
            # 头像来源，在V2中已移除该属性
            avatar:
            emoji:     #表情包地址详见https://waline.js.org/guide/features/emoji.html，饿了么提供的国内镜像（将 unpkg.com 替换为 npm.elemecdn.com）
                - https://npm.elemecdn.com/@waline/emojis@1.1.0/bilibili
                - https://npm.elemecdn.com/@waline/emojis@1.1.0/bmoji
                - https://npm.elemecdn.com/@waline/emojis@1.1.0/weibo
                - https://npm.elemecdn.com/@waline/emojis@1.2.0/qq
            # 回复时必填的内容
            requiredMeta:
                - name
                - email
                - url
            # 评论框的默认的文字
            placeholder: 欢迎留下宝贵的评论！
            # 自定义语言设置，参考https://waline.js.org/cookbook/customize/locale.html#locale-%E9%80%89%E9%A1%B9
            locale:
                admin: 会长
                sofa: 还没有人评论哦！快来抢沙发吧~
```

另外 `emoji` 官方提供了许多预设，可以查看[预设列表](https://waline.js.org/guide/features/emoji.html#%E9%A2%84%E8%AE%BE)自行选择。

但是官方提供的预设使用的 `unpkg` 经常会被墙而导致无法正常访问，这里推荐替换为饿了么提供的国内镜像（将 `unpkg.com` 替换为 `npm.elemecdn.com`）

![](images/image.png)

## 6. **参考案例与资源**

**开源博客模板**：https://github.com/adityatelange/hugo-PaperMod

**Hugo 官方文档**：https://gohugo.io/documentation/

**GitHub Actions 配置示例**：https://github.com/peaceiris/actions-hugo

**其他安装教程：**&#x68;ttps://baize.wiki/blog/how-to-build-blog/

